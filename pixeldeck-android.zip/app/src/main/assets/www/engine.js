export const W=128,H=160,N=6;
export const slots=['far_leg','far_arm','near_leg','torso','head','near_arm'];
export const defaults=()=>({version:1,head:0,torso:0,arms:0,legs:0,flip:false,motion:'idle',fps:8,poses:Array.from({length:N},()=>({})),name:'ตัวละครของฉัน'});
export function idOf(s){return ((s.head*20+s.torso)*10+s.arms)*10+s.legs+1;}
export function poseAt(s,f){
 const phase=f/N*Math.PI*2, wave=Math.sin(phase);
 if(s.motion==='custom')return {angles:s.poses[f]||{},dy:0};
 let angles={},dy=0;
 if(s.motion==='idle'){angles={head:wave*2,near_arm:wave*3,far_arm:-wave*3};dy=Math.round(wave);}
 if(s.motion==='walk'){angles={near_leg:wave*19,far_leg:-wave*19,near_arm:-wave*23,far_arm:wave*23};dy=-Math.round(Math.abs(wave)*2);}
 if(s.motion==='attack'){const swing=[0,25,45,-65,-35,0][f];angles={near_arm:swing,far_arm:swing/3,head:[0,-2,-4,5,3,0][f]};}
 if(s.motion==='float'){angles={near_arm:-12+wave*5,far_arm:12-wave*5};dy=-5-Math.round(wave*3);}
 return {angles,dy};
}
export function validateProject(p){
 if(!p||p.version!==1)throw new Error('รูปแบบโปรเจกต์ไม่รองรับ');
 for(const [k,max] of Object.entries({head:19,torso:19,arms:9,legs:9}))if(!Number.isInteger(p[k])||p[k]<0||p[k]>max)throw new Error('หมายเลขชิ้นส่วนไม่ถูกต้อง');
 if(!['idle','walk','attack','float','custom'].includes(p.motion)||!Number.isInteger(p.fps)||p.fps<2||p.fps>18||typeof p.flip!=='boolean')throw new Error('ข้อมูลแอนิเมชันไม่ถูกต้อง');
 if(!Array.isArray(p.poses)||p.poses.length!==N)throw new Error('ต้องมี 6 เฟรม');
 for(const pose of p.poses){if(!pose||typeof pose!=='object'||Array.isArray(pose))throw new Error('ข้อมูลท่าไม่ถูกต้อง');for(const [k,v] of Object.entries(pose))if(!slots.includes(k)||typeof v!=='number'||!Number.isFinite(v)||Math.abs(v)>65)throw new Error('มุมชิ้นส่วนไม่ถูกต้อง');}
 return {...defaults(),head:p.head,torso:p.torso,arms:p.arms,legs:p.legs,motion:p.motion,fps:p.fps,flip:p.flip,poses:p.poses.map(x=>({...x})),name:typeof p.name==='string'?p.name.slice(0,60):'ตัวละครของฉัน'};
}
export function draw(ctx,images,rig,s,frame=0,{scale=1,bg='transparent'}={}){
 ctx.save();ctx.setTransform(1,0,0,1,0,0);ctx.clearRect(0,0,W*scale,H*scale);ctx.imageSmoothingEnabled=false;
 if(bg!=='transparent'){ctx.fillStyle=bg==='green'?'#00ff00':'#ff00ff';ctx.fillRect(0,0,W*scale,H*scale);}
 ctx.scale(scale,scale);if(s.flip){ctx.translate(W,0);ctx.scale(-1,1);}
 const {angles,dy}=poseAt(s,frame);ctx.translate(0,dy+18);
 const refs={head:['head',s.head],torso:['torso',s.torso],near_arm:['arm',s.arms*2],far_arm:['arm',s.arms*2+1],near_leg:['leg',s.legs*2],far_leg:['leg',s.legs*2+1]};
 for(const slot of rig.drawOrder){const [kind,idx]=refs[slot];const image=images[`${kind}_${String(idx).padStart(2,'0')}`];const [x,y]=rig.slots[slot], [px,py]=rig.pivotLocal[kind];ctx.save();ctx.translate(x+px,y+py);ctx.rotate((angles[slot]||0)*Math.PI/180);ctx.drawImage(image,-px,-py);ctx.restore();}
 ctx.restore();
}
const crcTable=Array.from({length:256},(_,i)=>{for(let j=0;j<8;j++)i=(i&1)?0xedb88320^(i>>>1):i>>>1;return i>>>0;});
export function zipStore(files){
 const encoder=new TextEncoder(),chunks=[],central=[];let offset=0;
 const put=(size)=>{const a=new Uint8Array(size);return [a,new DataView(a.buffer)];};
 for(const [name,bytes] of files){const n=encoder.encode(name),data=typeof bytes==='string'?encoder.encode(bytes):bytes;let crc=0xffffffff;for(const b of data)crc=crcTable[(crc^b)&255]^(crc>>>8);crc=(crc^0xffffffff)>>>0;
 const [a,v]=put(30+n.length);v.setUint32(0,0x04034b50,true);v.setUint16(4,20,true);v.setUint16(6,0x800,true);v.setUint32(14,crc,true);v.setUint32(18,data.length,true);v.setUint32(22,data.length,true);v.setUint16(26,n.length,true);a.set(n,30);chunks.push(a,data);
 const [c,cv]=put(46+n.length);cv.setUint32(0,0x02014b50,true);cv.setUint16(4,20,true);cv.setUint16(6,20,true);cv.setUint16(8,0x800,true);cv.setUint32(16,crc,true);cv.setUint32(20,data.length,true);cv.setUint32(24,data.length,true);cv.setUint16(28,n.length,true);cv.setUint32(42,offset,true);c.set(n,46);central.push(c);offset+=a.length+data.length;
 }
 const size=central.reduce((sum,x)=>sum+x.length,0);const [end,ev]=put(22);ev.setUint32(0,0x06054b50,true);ev.setUint16(8,files.length,true);ev.setUint16(10,files.length,true);ev.setUint32(12,size,true);ev.setUint32(16,offset,true);
 return new Blob([...chunks,...central,end],{type:'application/zip'});
}
