package com.pixeldeck.studio;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.util.Base64;
import android.webkit.*;
import android.widget.Toast;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
 private WebView web;
 private byte[] pending;
 private ValueCallback<Uri[]> chooser;
 private static final String HOST="appassets.androidplatform.net";
 @Override public void onCreate(Bundle state){
  super.onCreate(state);
  getWindow().setStatusBarColor(0xff11151b);
  getWindow().setNavigationBarColor(0xff11151b);
  web=new WebView(this);setContentView(web);
  WebSettings settings=web.getSettings();settings.setJavaScriptEnabled(true);settings.setDomStorageEnabled(true);
  settings.setAllowFileAccess(false);settings.setAllowContentAccess(true);
  settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
  web.addJavascriptInterface(new SaveBridge(),"PixelDeckAndroid");
  web.setWebViewClient(new WebViewClient(){
   @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest req){return !local(req.getUrl());}
   @Override public WebResourceResponse shouldInterceptRequest(WebView view,WebResourceRequest req){
    Uri u=req.getUrl();if(!local(u))return blocked();
    String p=u.getPath();if(p==null||!p.startsWith("/assets/")||p.contains(".."))return blocked();
    String file=p.substring(8);
    try{return new WebResourceResponse(mime(file),"UTF-8",getAssets().open(file));}catch(IOException e){return blocked();}
   }
  });
  web.setWebChromeClient(new WebChromeClient(){
   @Override public boolean onShowFileChooser(WebView w,ValueCallback<Uri[]> callback,FileChooserParams params){
    if(chooser!=null)chooser.onReceiveValue(null);chooser=callback;
    Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");
    startActivityForResult(i,2);return true;
   }
  });
  web.loadUrl("https://"+HOST+"/assets/www/index.html");
 }
 private boolean local(Uri u){return "https".equals(u.getScheme())&&HOST.equals(u.getHost());}
 private WebResourceResponse blocked(){return new WebResourceResponse("text/plain","UTF-8",404,"Not Found",Collections.emptyMap(),new ByteArrayInputStream(new byte[0]));}
 private String mime(String p){if(p.endsWith(".html"))return "text/html";if(p.endsWith(".js"))return "application/javascript";if(p.endsWith(".css"))return "text/css";if(p.endsWith(".json"))return "application/json";if(p.endsWith(".png"))return "image/png";return "application/octet-stream";}
 public class SaveBridge {
  @JavascriptInterface public void saveFile(String filename,String type,String data){
   if(data.length()>24000000){runOnUiThread(()->toast("ไฟล์ใหญ่เกินไป"));return;}
   final byte[] bytes;try{bytes=Base64.decode(data,Base64.DEFAULT);}catch(IllegalArgumentException e){return;}
   runOnUiThread(()->{
    if(pending!=null){toast("บันทึกไฟล์ก่อนหน้าก่อนครับ");return;}
    pending=bytes;Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);
    i.setType(type==null||type.isEmpty()?"application/octet-stream":type);i.putExtra(Intent.EXTRA_TITLE,filename.replaceAll("[^a-zA-Z0-9._-]","_"));
    startActivityForResult(i,1);
   });
  }
 }
 @Override protected void onActivityResult(int request,int result,Intent data){
  super.onActivityResult(request,result,data);
  if(request==2&&chooser!=null){chooser.onReceiveValue(result==RESULT_OK&&data!=null&&data.getData()!=null?new Uri[]{data.getData()}:null);chooser=null;}
  if(request==1){final byte[] bytes=pending;pending=null;
   if(result==RESULT_OK&&data!=null&&data.getData()!=null&&bytes!=null){final Uri uri=data.getData();new Thread(()->{try(OutputStream out=getContentResolver().openOutputStream(uri)){if(out==null)throw new IOException();out.write(bytes);runOnUiThread(()->toast("บันทึกไฟล์แล้ว"));}catch(IOException e){runOnUiThread(()->toast("บันทึกไม่สำเร็จ กรุณาลองอีกครั้ง"));}}).start();}
  }
 }
 private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
 @Override public void onBackPressed(){web.evaluateJavascript("(()=>{const d=document.querySelector('dialog[open]');if(d){d.close();return true;}return false;})()",v->{if(!"true".equals(v))MainActivity.super.onBackPressed();});}
 @Override protected void onDestroy(){if(chooser!=null)chooser.onReceiveValue(null);web.removeJavascriptInterface("PixelDeckAndroid");web.destroy();super.onDestroy();}
}
