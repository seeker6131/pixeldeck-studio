PixelDeck Studio Android — ชุดต้นฉบับ ไม่ใช่ไฟล์ APK
มีภาพครบ80ชิ้น รองรับการประกอบ40000แบบ ใช้ในเครื่องแบบออฟไลน์
Export PNG/ZIP/JSON ผ่านตัวเลือกบันทึกไฟล์ Android และนำเข้าโปรเจกต์ผ่านตัวเลือกไฟล์
สร้างด้วย Gradle 8.11.1 + JDK17 + Android SDK35 + AGP8.9.2
คำสั่ง: gradle :app:assembleDebug --no-daemon
ผลลัพธ์: app/build/outputs/apk/debug/app-debug.apk
ยังไม่ได้คอมไพล์และทดลองติดตั้งจริงในสภาพแวดล้อมนี้ ให้ตรวจผล GitHub Actions
APK สำหรับทดลองใช้ส่วนตัว เซ็นด้วย debug key ของเครื่องที่ build
หาก build ใหม่เปลี่ยนคีย์ อาจต้องถอนแอปเดิมก่อนติดตั้ง: สำรองโปรเจกต์ JSON ก่อน
